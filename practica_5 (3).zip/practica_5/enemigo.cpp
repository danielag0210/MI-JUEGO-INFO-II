#include "enemigo.h"

enemigo::enemigo()
{

}
