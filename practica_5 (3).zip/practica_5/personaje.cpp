#include "personaje.h"
#include <QPainter>
#include <QPixmap>

personaje::personaje():QGraphicsItem()
{
}

personaje::personaje(int x, int y, int l, int a, QString b, int v)
{   this->posx=x;
    this->posy=y;
    this->largo=l;
    this->ancho=a;
    this->url=b;
    this->velocidad=v;
}

QRectF personaje::boundingRect() const
{
    return QRectF(posx, posy,largo,ancho);
}

void personaje::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *)
{
    QPixmap personaje(url);
    painter->drawPixmap(boundingRect(), personaje, personaje.rect());
}

void personaje::MoveUp()
{   posy=posy-velocidad;
    setPos(posx,posy);
}

void personaje::MoveDown()
{
    posy=posy+velocidad;
    setPos(posx,posy);
}

void personaje::MoveRight()
{     posx=posx+velocidad;
    setPos(posx,posy);
}
void personaje::Moveleft()
{
    posx=posx-velocidad;
    setPos(posx,posy);
}

