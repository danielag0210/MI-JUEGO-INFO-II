#ifndef PERSONAJE_H
#define PERSONAJE_H

#include <QGraphicsItem>
#include <QString>
#include <QPixmap>
#include <QKeyEvent>

#include "personaje.h"

class personaje : public QGraphicsItem {
    int posx, posy, largo, ancho,velocidad;
    QString url;
public:
    personaje();
    personaje(int x, int y, int l, int a, QString b, int v);
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

    void MoveUp();
    void Moveleft();
    void MoveDown();
    void MoveRight();
};

#endif // PERSONAJE_H
