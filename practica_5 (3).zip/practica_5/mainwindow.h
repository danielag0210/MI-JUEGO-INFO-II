#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QString>
#include <QMainWindow>
#include <QGraphicsScene>
#include <QKeyEvent>
#include <QList>

#include "bloque.h"
#include "personaje.h"
#include "juego.h"


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    MainWindow(QWidget *parent = nullptr);
    void crearmapa(QGraphicsScene *escena, char tablero[27][40]);
    void keyPressEvent(QKeyEvent* teclas);

    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QGraphicsScene *escena;
    bloque *muro;
    bloque *pasto;
    QString b;
    personaje *mago;
};
#endif // MAINWINDOW_H
