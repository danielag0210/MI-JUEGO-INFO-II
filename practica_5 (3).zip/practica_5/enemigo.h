#ifndef ENEMIGO_H
#define ENEMIGO_H

class enemigo
{
public:
    enemigo();
};

#endif // ENEMIGO_H
