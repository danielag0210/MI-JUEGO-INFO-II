#include "juego.h"
#include "personaje.h"

juego::juego(QGraphicsScene* escena) : escena1(escena)
{
    mago = new personaje(0, 0, 20, 20, ":/imagenes/mago.png", 3);
    escena->addItem(mago);
}

void juego::keyPressEvent(QKeyEvent* teclas)
{
    if (teclas->key() == Qt::Key_W) {
        mago->MoveUp();

    } else if (teclas->key() == Qt::Key_S) {
        mago->MoveDown();

    } else if (teclas->key() == Qt::Key_A) { // Izquierda
        mago->Moveleft();

    } else if (teclas->key() == Qt::Key_D) { // Derecha

    }
}


