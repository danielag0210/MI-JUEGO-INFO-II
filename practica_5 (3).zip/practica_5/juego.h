
#ifndef JUEGO_H
#define JUEGO_H

#include <QKeyEvent>
#include <QGraphicsScene>
#include "personaje.h"

class juego {
private:
    personaje* mago;
    QGraphicsScene* escena1;

public:
    juego(QGraphicsScene* escena);
    void keyPressEvent(QKeyEvent* teclas);
};

#endif // JUEGO_H

