#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QString>
#include <QMainWindow>
#include <QGraphicsItem>

#include "bloque.h"
#include "personaje.h"
#include "juego.h"

char tablero[27][40] = {
    {"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"},
    {"x                                     x"},
    {"x  xxxxxxxx  xxxxxxxxxxxxxxx xxxxxxx  x"},
    {"x  x                               x  x"},
    {"x  x  xxxx  x   xxxxxxx   x  xxxx  x  x"},
    {"x  x  x  x  x   xx   xx   x  x  x  x  x"},
    {"x  x  x  x  x   xx   xx   x  x  x  x  x"},
    {"x  x  x  x  x             x  x  x  x  x"},
    {"xxxx  x  x  xxxxxx   xxxxxx  x  x  xxxx"},
    {"x     x  x       x   x       x  x     x"},
    {"xxxxxxx  xxxxxxxxx   xxxxxxxxx  xxxxxxx"},
    {"x                                     x"},
    {"x     x  x                   x  x     x"},
    {"x     x  x                   x  x     x"},
    {"xxxxxxx  x  xxxxxx   xxxxxx  x  xxxxxxx"},
    {"x        x  xxxxxx   xxxxxx  x        x"},
    {"xxxxxxxxxx  xxxxxx   xxxxxx  xxxxxxxxxx"},
    {"x                                     x"},
    {"x                                     x"},
    {"xxxxxxxxxx  xxxxxxxxxxxxxxx  xxxxxxxxxx"},
    {"xxxxxxxxxx  x             x  xxxxxxxxxx"},
    {"xxxxxxxxxx  x             x  xxxxxxxxxx"},
    {"xxxxxxxxxx  xxxxx     xxxxx  xxxxxxxxxx"},
    {"xxxxxxxxxx                   xxxxxxxxxx"},
    {"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"}
};

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    //Escenario
    escena=new QGraphicsScene;
    ui->setupUi(this);
    escena->setSceneRect(0, 0, 1000, 700);
    ui->graphicsView->setScene(escena);

    //Mapa
    crearmapa(escena,tablero);
    setStyleSheet("background-color: black;");
    mago = new personaje(0, 0, 25, 25, ":/imagenes/mago.png", 3);
    escena->addItem(mago);
}

void MainWindow::crearmapa(QGraphicsScene *escena, char tablero[27][40]){
    // Calcular el ancho y alto de cada cada cuadro en la matriz
    int  anchoc = 25;
    int  altoc =  25;

    for (int y = 0; y < 27; y++) {
       for (int x = 0; x < 40; x++) {
           if (tablero[y][x] == 'x') {
               // Calcular la posición del objeto muro
               int posX = x * anchoc;
               int posY = y * altoc;
               // Crear el objeto muro y agregarlo a la escena
               muro = new bloque(posX, posY, anchoc, altoc,":/imagenes/bloque.jpg");
               escena->addItem(muro);
                      //esta lista me almacena todas los muros y me sirve para las colisiones, ya que tengo su posicion y es como una lista que guarda objetos
           }

          else if (tablero[y][x]==' ') {
               int posX = x * anchoc;
               int posY = y * altoc;
               pasto = new bloque(posX, posY, anchoc, altoc,":/imagenes/pasto.png");
               escena->addItem(pasto);
           }

           else if (tablero[y][x]==' ') {
               int posX = x * anchoc;
               int posY = y * altoc;
               pasto = new bloque(posX, posY, anchoc, altoc,":/imagenes/pasto.png");
               escena->addItem(pasto);
           }
       }
    }
}

void MainWindow::keyPressEvent(QKeyEvent* teclas)
{
    if (teclas->key() == Qt::Key_W) {
       mago->MoveUp();

    } else if (teclas->key() == Qt::Key_S) {
       mago->MoveDown();

    } else if (teclas->key() == Qt::Key_A) { // Izquierda
       mago->Moveleft();

    } else if (teclas->key() == Qt::Key_D) { // Derecha
       mago->MoveRight();
    }
}

MainWindow::~MainWindow()
{
    delete escena;
    delete ui;

}

