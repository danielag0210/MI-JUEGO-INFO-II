#ifndef BALA_H
#define BALA_H


class bala
{
public:
    bala();
};

#endif // BALA_H
