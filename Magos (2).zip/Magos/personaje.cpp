#include "personaje.h"

personaje::personaje()
{
    personaje_p[n_base]=new objetos(":/imagenes/Mago_paso1_arriba.png",n_ancho_sprite,n_alto_sprite);//la imagen que queremos proyectar del pacman
    movimiento = personaje_p[n_base];//paara ensayar funcion comer
    velocidad=2;//esto representa la cantidad de pixeles que avanza
    caminar_t=0;//vamos a utilizar esto para los tiempos de comida
    caminar1=false;//quiere significar que no hay comida
    direccion='z';//significa la direccion de movimiento
    paso_actua = 'b';
    principal_personaje();
}

void personaje::principal_personaje()
{
    personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso1_arriba.png",n_ancho_sprite,n_alto_sprite);
    personaje_p[n_abajo]=new objetos(":/imagenes/Mago_paso1_frente.png",n_ancho_sprite,n_alto_sprite);
    personaje_p[n_derecha]=new objetos(":/imagenes/Mago_paso1_derecha.pnga",n_ancho_sprite,n_alto_sprite);
    personaje_p[n_izquierda]=new objetos(":/imagenes/Mago_paso1_izq.png",n_ancho_sprite,n_alto_sprite);
}

objetos *personaje::get_personaje_p(int numero_p)
{
    return personaje_p[numero_p];
}

void personaje::personaje_arriba_c(char cara)
{ //delete personaje_p[n_arriba];
    if (cara=='b'){personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso1_arriba.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='c'){personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso2_arriba.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='d'){personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso3_arriba.png",n_ancho_sprite,n_alto_sprite);}
}

void personaje::personaje_abajo_c(char cara)
{//delete personaje_p[n_abajo];
    if (cara=='b'){personaje_p[n_abajo]=new objetos(":/imagenes/Mago_paso1_frente.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='c'){personaje_p[n_abajo]=new objetos(":/imagenes/Mago_paso2_frente.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='d'){personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso3_frente.png",n_ancho_sprite,n_alto_sprite);}
}

void personaje::personaje_derecha_c(char cara)
{//delete personaje_p[n_derecha];
    if (cara=='b'){personaje_p[n_derecha]=new objetos(":/imagenes/Mago_paso1_derecha.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='c'){personaje_p[n_derecha]=new objetos(":/imagenes/Mago_paso2_derecha.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='d'){personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso3_derecha.png",n_ancho_sprite,n_alto_sprite);}
}

void personaje::personaje_izquierda_c(char cara)
{//delete personaje_p[n_izquierda];
    if (cara=='b'){personaje_p[n_izquierda]=new objetos(":/imagenes/Mago_paso1_izq.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='c'){personaje_p[n_izquierda]=new objetos(":/imagenes/mago_paso2_izq.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='d'){personaje_p[n_arriba]=new objetos(":/imagenes/mago_paso3_izq.png",n_ancho_sprite,n_alto_sprite);}
}


/*void personaje::caminar()
{
    caminar1=true;
    personaje_arriba_c('c');
    personaje_abajo_c('c');
    personaje_izquierda_c('c');
    personaje_derecha_c('c');
    caminar_t=caminar_t+1;
    if(caminar1==true and caminar_t==2){
        caminar_t=caminar_t+1;
        personaje_arriba_c('b');
        personaje_abajo_c('b');
        personaje_izquierda_c('b');
        personaje_derecha_c('b');
    }
    else if(caminar1==true and caminar_t==3){
        caminar_t=0;
        caminar1=false;
        personaje_arriba_c('d');
        personaje_abajo_c('d');
        personaje_izquierda_c('d');
        personaje_derecha_c('d');
    }
}*/


void personaje::caminar()
{caminar1=true;
    personaje_arriba_c('c');
    personaje_abajo_c('c');
    personaje_izquierda_c('c');
    personaje_derecha_c('c');
    caminar_t=caminar_t+1;
    if(caminar1==true and caminar_t==2){
        caminar_t=0;
        caminar1=false;
        personaje_arriba_c('b');
        personaje_abajo_c('b');
        personaje_izquierda_c('b');
        personaje_derecha_c('b');
    }
}

personaje::~personaje()
{
    delete    personaje_p[n_base];
    delete    personaje_p[n_arriba];
    delete    personaje_p[n_abajo];
    delete    personaje_p[n_derecha];
    delete    personaje_p[n_izquierda];
}

/*void personaje::comer2()
{
    if (paso_actua == 'b') {
        personaje_arriba_c('b');
        personaje_abajo_c('b');
        personaje_izquierda_c('b');
        personaje_derecha_c('b');
    } else if (paso_actua == 'c') {
        personaje_arriba_c('c');
        personaje_abajo_c('c');
        personaje_izquierda_c('c');
        personaje_derecha_c('c');

    }

    comida_t = comida_t + 1;

    if (comida && comida_t == 2) {
        comida_t = 0;
        comida = false;

        if (paso_actua == 'b') {
            paso_actua = 'c';
        }
    }
}*/
void personaje::moverV2(char direccion)
{
    if(direccion=='w'){
        movimiento->setY(movimiento->y()-velocidad);}

    else if(direccion=='s'){
        movimiento->setY(movimiento->y()+velocidad);}


    else if(direccion=='a'){
        movimiento->setX(movimiento->x()-velocidad);}

    else if(direccion=='d'){
        movimiento->setX(movimiento->x()+velocidad);}
}
