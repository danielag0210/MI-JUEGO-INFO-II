#include "bloque.h"
#include <QPainter>

bloque::bloque() : QGraphicsItem()
{
}

bloque::bloque(int x, int y, int l, int a, QString b)
{   this->posx=x;
    this->posy=y;
    this->largo=l;
    this->ancho=a;
    this->url=b;
}

QRectF bloque::boundingRect() const
{
    return QRectF(posx, posy,largo,ancho);
}

void bloque::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *)
{
    QPixmap bloque1(url);
    painter->drawPixmap(boundingRect(), bloque1, bloque1.rect());
}
