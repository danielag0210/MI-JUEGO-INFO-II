#ifndef CONTROL_MAESTRO_H
#define CONTROL_MAESTRO_H

#define n_arriba 0
#define n_abajo 1
#define n_derecha 2
#define n_izquierda 3
#define n_base 4
#define gemavalor 50

#include "personaje.h"
#include "mainwindow.h"
#include "objetos.h"
#include "bloque.h"
#include "enemigos.h"
#include "llave.h"
#include "duende.h"

#include "ui_mainwindow.h"
#include "control_maestro.h"
#include "personaje.h"
#include "iostream"


#include <QMainWindow>
#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
#include <QKeyEvent>
#include <QTimer>
#include <QList>
#include <QWidget>
#include <random>
#include <cstdlib>
#include <QString>
#include <ctime>

class personaje;
class MainWindow;
class objetos;
class enemigos;
class duende;

class control_maestro:public QObject, public QGraphicsPixmapItem
{
public:

    control_maestro(MainWindow* mainWindow);
    ~control_maestro();
    void mover_personaje();
    void agregarMovimiento();
    void keyPressEvent(QKeyEvent* event);
    void crearmapa(QGraphicsScene *escena, char tablero[32][40]);
    bool colision(int posx_inc, int posy_inc, char direccion);
    void telepor_pacman(int posx, int posy);
    void fin_de_juego();
    void colisionesfantasmas();
    void focus(QGraphicsItem *item);
    int  LlaveAleatoria();
    void Ganador(char llave1);
    void varita();
    void mostrarPerdiste();
    void ocultarPerdiste();

    void gemita();
    void mostrarsangre();
    void ocultarsangre();
public slots://la utilizamos para el Qtimer
    void aggrgarMovimiento_caminar();

private:


    bool inicio_juego;
    bool colision_enemigo;
    bool llavetomada1;

    QGraphicsItem *arana1;
    QGraphicsItem *llaveabrir;

    QLCDNumber* lcdnumero;
    int numero;
    char direccion;
    char llave3;

    personaje* mago;
    enemigos* arana;
    duende* duende1;

    //objetos *movimiento_p;
    MainWindow *pantalla_juego;
    MainWindow* mainWindow;
    QGraphicsScene* escena;
    QGraphicsScene* escenaFinal;

    QTimer* timer;
    QTimer* timer_enemigos;
    QTimer* timer_enemigos1;
    QTimer* timerColisiones;
    QTimer* timer_caminar;

    objetos *pasto;
    objetos* finjuego;

    bloque *perdiste;
    bloque *sangre;
    bloque *muro;
    bloque *baul;
    llave *llabe;
    bloque *gema;

    QList<bloque*>gemas;
    QList<llave*>llaves;
};

#endif // CONTROL_MAESTRO_H
