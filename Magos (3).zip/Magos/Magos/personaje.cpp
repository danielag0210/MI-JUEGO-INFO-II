#include "personaje.h"

personaje::personaje()
{
    personaje_p[n_base]=new objetos(":/imagenes/Mago_paso1_arriba.png",n_ancho_sprite,n_alto_sprite);//la imagen que queremos proyectar del pacman
    movimiento = personaje_p[n_base];//paara ensayar funcion comer
    velocidad=3;//esto representa la cantidad de pixeles que avanza
    caminar_t=0;//vamos a utilizar esto para los tiempos de comida
    caminar1=false;//quiere significar que no hay comida
    direccion='z';//significa la direccion de movimiento
    paso_actua = 'b';
    vida=15;
    principal_personaje();
}

int personaje::obtener_vida() {
    return vida;
}

void personaje::reducir_vida(int cantidad) {
    vida=vida-cantidad;
}

void personaje::aumentar_vida(int cantidad) {
    vida=vida+cantidad;
}

void personaje::principal_personaje()
{
    personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso1_arriba.png",n_ancho_sprite,n_alto_sprite);
    personaje_p[n_abajo]=new objetos(":/imagenes/Mago_paso1_frente.png",n_ancho_sprite,n_alto_sprite);
    personaje_p[n_derecha]=new objetos(":/imagenes/Mago_paso1_derecha.pnga",n_ancho_sprite,n_alto_sprite);
    personaje_p[n_izquierda]=new objetos(":/imagenes/Mago_paso1_izq.png",n_ancho_sprite,n_alto_sprite);
}

objetos *personaje::get_personaje_p(int numero_p)
{
    return personaje_p[numero_p];
}

void personaje::personaje_arriba_c(char cara)
{  if (cara=='b'){personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso1_arriba.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='c'){personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso2_arriba.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='d'){personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso3_arriba.png",n_ancho_sprite,n_alto_sprite);}
}

void personaje::personaje_abajo_c(char cara)
{   if (cara=='b'){personaje_p[n_abajo]=new objetos(":/imagenes/Mago_paso1_frente.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='c'){personaje_p[n_abajo]=new objetos(":/imagenes/Mago_paso2_frente.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='d'){personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso3_frente.png",n_ancho_sprite,n_alto_sprite);}
}

void personaje::personaje_derecha_c(char cara)
{
    if (cara=='b'){personaje_p[n_derecha]=new objetos(":/imagenes/Mago_paso1_derecha.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='c'){personaje_p[n_derecha]=new objetos(":/imagenes/Mago_paso2_derecha.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='d'){personaje_p[n_arriba]=new objetos(":/imagenes/Mago_paso3_derecha.png",n_ancho_sprite,n_alto_sprite);}
}

void personaje::personaje_izquierda_c(char cara)
{
    if (cara=='b'){personaje_p[n_izquierda]=new objetos(":/imagenes/Mago_paso1_izq.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='c'){personaje_p[n_izquierda]=new objetos(":/imagenes/mago_paso2_izq.png",n_ancho_sprite,n_alto_sprite);}
    else if(cara=='d'){personaje_p[n_arriba]=new objetos(":/imagenes/mago_paso3_izq.png",n_ancho_sprite,n_alto_sprite);}
}


void personaje::caminar()
{caminar1=true;
    personaje_arriba_c('c');
    personaje_abajo_c('c');
    personaje_izquierda_c('c');
    personaje_derecha_c('c');
    caminar_t=caminar_t+1;
    if(caminar1==true and caminar_t==2){
        caminar_t=0;
        caminar1=false;
        personaje_arriba_c('b');
        personaje_abajo_c('b');
        personaje_izquierda_c('b');
        personaje_derecha_c('b');
    }
}

void personaje::moverV2(char direccion)
{
    if(direccion=='w'){
        movimiento->setY(movimiento->y()-velocidad);}

    else if(direccion=='s'){
        movimiento->setY(movimiento->y()+velocidad);}


    else if(direccion=='a'){
        movimiento->setX(movimiento->x()-velocidad);}

    else if(direccion=='d'){
        movimiento->setX(movimiento->x()+velocidad);}
}

personaje::~personaje()
{
    delete    personaje_p[n_base];
    delete    personaje_p[n_arriba];
    delete    personaje_p[n_abajo];
    delete    personaje_p[n_derecha];
    delete    personaje_p[n_izquierda];
}

