#ifndef GEMAS_H
#define GEMAS_H

#include <QGraphicsItem>
#include <QString>
#include "gemas.h"

class gemas : public QGraphicsItem {
    int vida, posx, posy, largo, ancho;
    QString url;
public:
    gemas();
    gemas(int v, int x, int y, int l, int a, QString b);
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};

#endif // BLOQUE_H
