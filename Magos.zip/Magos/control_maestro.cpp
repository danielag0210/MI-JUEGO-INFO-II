#include "control_maestro.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "control_maestro.h"
#include "personaje.h"
#include "iostream"
#include "tablero.cpp"
#include <iostream>
#include <QTimer>

using namespace std;

control_maestro::control_maestro(MainWindow* mainWindow)
{   this->pantalla_juego = mainWindow;
    this->escena = mainWindow->getEscena();

    mago=new personaje();

    arana=new enemigos(0);
    arana->velocidad = 4;

    duende=new enemigos(1);
    duende->velocidad = 7;

    inicio_juego=true;
    llavetomada1=false;
    llave3 = LlaveAleatoria();

    //Mapa
    crearmapa(escena,tablero);
    pasto = new objetos(":/imagenes/pasto.png",950,750);
    pantalla_juego->setStyleSheet("background-color: black;");
    pasto->setZValue(-1);
    escena->addItem(pasto);

    arana->start='1';
    timer_enemigos = new QTimer();
    QObject::connect(timer_enemigos, SIGNAL(timeout()), arana, SLOT(mover()));
         timer_enemigos->start(60); // Intervalo de tiempo en milisegundos para mover a los enemigos (ajusta según tus necesidades)

    duende->start='1';
    timer_enemigos_d = new QTimer();
    QObject::connect(timer_enemigos_d, SIGNAL(timeout()), duende, SLOT(mover()));
      timer_enemigos_d->start(80);


    QTimer *timerColisiones = new QTimer(this);
    connect(timerColisiones, &QTimer::timeout, this, &control_maestro::colisionesfantasmas);
    timerColisiones->start(50);

    pantalla_juego->getUI()->graphicsView->setScene(escena);
         direccion='z';
         numero=0;
         //lcdnumero=pantalla_juego->getUI()->lcdNumber;
         //esto se utiliza para cambiar el color y texto de textBrouser
        // QColor color(Qt::red);
        // QTextCharFormat format;
        // format.setForeground(color);
       //  pantalla_juego->getUI()->textBrowser->setCurrentCharFormat(format);
      //   pantalla_juego->getUI()->textBrowser->append("Tu puntaje es:");
        // pantalla_juego->getUI()->textBrowser->setStyleSheet("border: none;");
         aggrgarMovimiento_caminar();

}

int control_maestro::LlaveAleatoria() {
         int llave2 = rand() % 2;
         return llave2;
}


void control_maestro::aggrgarMovimiento_caminar()
{  timer_caminar=new QTimer();
    QObject::connect(timer_caminar, SIGNAL(timeout()), mago, SLOT(caminar()));
    timer_caminar->start(100);
}


void control_maestro::focus(QGraphicsItem *item){
    QRectF pos = escena->sceneRect();
    escena->setSceneRect(
        pos.x(),
        pos.y(),
        escena->width(),
        escena->height()
    );
}


void control_maestro::keyPressEvent(QKeyEvent* event)
{
    focus(mago->movimiento);

        if (event->key() == Qt::Key_W) { // Arriba
            direccion='w';
            varita();

            if(colision(mago->movimiento->x(),mago->movimiento->y()-mago->velocidad,direccion)==false){//aqui hacemos que haga el paso para verificar si se puede hacer
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_arriba)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_arriba)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_arriba);
                mago->moverV2(direccion);
                mago->x_o_y='w';
                escena->addItem(mago->movimiento);
            }
            else{
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_base)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_base)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_base);
                escena->addItem(mago->movimiento);
            }
        }

        else if (event->key() == Qt::Key_S) { // abajo
            direccion='s';
            varita();
            if(colision(mago->movimiento->x(),mago->movimiento->y()+mago->velocidad,direccion)==false){
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_abajo)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_abajo)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_abajo);
                mago->moverV2(direccion);
                mago->x_o_y='s';
                escena->addItem(mago->movimiento);
            }
            else{
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_base)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_base)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_base);
                escena->addItem(mago->movimiento);
            }

        }
        else if (event->key() == Qt::Key_D) { // derecha
            direccion='d';
            varita();
            if(colision(mago->movimiento->x()+mago->velocidad,mago->movimiento->y(),direccion)==false){
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_derecha)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_derecha)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_derecha);
                mago->moverV2(direccion);
                mago->x_o_y='d';
                escena->addItem(mago->movimiento);
            }
            else{
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_base)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_base)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_base);
                escena->addItem(mago->movimiento);
            }

        }
        else if (event->key() == Qt::Key_A) { // izquierda
            direccion='a';
            varita();
            if(colision(mago->movimiento->x()-mago->velocidad,mago->movimiento->y(),direccion)==false){
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_izquierda)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_izquierda)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_izquierda);
                mago->moverV2(direccion);
                mago->x_o_y='a';
                escena->addItem(mago->movimiento);
            }
            else{
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_base)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_base)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_base);
                escena->addItem(mago->movimiento);
            }
      }
}



void control_maestro::crearmapa(QGraphicsScene *escena, char tablero[31][40]){
    // Calcular el ancho y alto de cada  cuadro en la matriz
    int  anchoc = 25;
    int  altoc =  25;
    int  aranas = 0;
    int  duendes = 0;
    //macros
    pantalla_juego->tamano_de_la_escena(0,0,1100,780);//aqui le damos el tamaño a la escena
    pantalla_juego->setGeometry(0,0,1100,780);//aqui le damos tamaño al la pantalla

    for (int y = 0; y < 32; y++) {
        for (int x = 0; x < 40; x++) {
            if (tablero[y][x] == 'x') {
                // Calcular la posición del objeto muro
                int posX = x * anchoc;
                int posY = y * altoc;
                // Crear el objeto muro y agregarlo al grupo
                muro = new bloque(posX, posY, anchoc, altoc, ":/imagenes/bloque.jpg");
                escena->addItem(muro);
            }
             else if (tablero_lugares[y][x] == 'm') {
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    mago->movimiento->setPos(posX,posY);
            }
            else if(tablero_lugares[y][x]=='a'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    arana->get_enemigo(aranas)->setPos(posX,posY);
                    escena->addItem(arana->get_enemigo(aranas));
                    aranas=aranas+1;
            }
            else if(tablero_lugares[y][x]=='d'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    duende->get_enemigo(duendes)->setPos(posX,posY);
                    escena->addItem(duende->get_enemigo(duendes));
                    duendes=duendes+1;
            }
            else if(tablero_lugares[y][x]=='b'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    baul = new bloque(posX,posY,40,35,":/imagenes/baul.png");
                    escena->addItem(baul);
            }
            else if(tablero_lugares[y][x]=='y'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    llave = new bloque(posX,posY,20,30,":/imagenes/llave-removebg-preview.png");
                    llaves.append(llave);
                    escena->addItem(llave);
            }
            else if(tablero_lugares[y][x]=='g'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    gema = new bloque(posX,posY,20,20,":/imagenes/diamantes-removebg-preview (2).png");
                    gemas.append(gema);
                    escena->addItem(gema);
            }
        }
    }
}

    bool control_maestro::colision(int posx_inc, int posy_inc, char direccion)
{
    int ancho = 25;
    int alto =  25;
    int objeto_x = posx_inc / ancho;
    int objeto_y = posy_inc / alto;
    int fila = objeto_y + 1;  // Sumar 1 para compensar el índice base 0 en C++
    int columna = objeto_x + 1;  // Sumar 1 para compensar el índice base 0 en C++

    if (direccion == 'w') {
        // hay que colocar las siguientes condiciones:
        // si pos_inc y % alto == 0 true
        // si la x - velm % == 0
        // si la x % != 0 pero y % == 0
        // si la x % != 0 y y % != 0
        if (posy_inc % alto == 0) {
            return false;
        }
        else if ((posy_inc - mago->velocidad) % ancho == 0 and tablero[fila - 1][columna - 1] == 'x') {
            return true;
        }
        else if ((posy_inc) % ancho != 0 and posx_inc % alto == 0) {
            if (tablero[fila - 1][columna - 1] == 'x') {
                return true;
            }
        }
        else if ((posy_inc) % ancho != 0 and posx_inc % alto != 0) {
            if (tablero[fila - 1][columna - 1] == 'x' or tablero[fila-1][columna] == 'x') {
                return true;
            }
        }
    }
    else if (direccion == 's') {
        if (posy_inc % alto == 0) {
            return false;
        }
        else if ((posy_inc - mago->velocidad) % ancho == 0 and tablero[fila][columna-1] == 'x') {
            return true;
        }
        else if ((posy_inc) % ancho != 0 and posx_inc % alto == 0) {
            if (tablero[fila][columna-1] == 'x') {
                return true;
            }
        }
        else if ((posy_inc) % ancho != 0 and posx_inc % alto != 0) {
            if (tablero[fila][columna - 1] == 'x' or tablero[fila][columna] == 'x') {
                return true;
            }
        }
    }
    else if (direccion == 'd') {
        if (posx_inc % ancho == 0) {
            return false;
        }
        else if ((posx_inc - mago->velocidad) % ancho == 0 and tablero[fila-1][columna] == 'x') {
            return true;
        }
        else if ((posx_inc) % ancho != 0 and posy_inc%alto == 0) {
            if (tablero[fila - 1][columna] == 'x') {
                return true;
            }
        }
        else if ((posx_inc) % ancho != 0 and posy_inc%alto != 0) {
            if (tablero[fila][columna] == 'x' or tablero[fila-1][columna] == 'x') {
                return true;
            }
        }
    }
    else if (direccion == 'a') {
        if (posx_inc % ancho == 0) {
            return false;
        }
        else if ((posx_inc - mago->velocidad) % ancho == 0 and tablero[fila - 1][columna - 1] == 'x') {
            return true;
        }
        else if ((posx_inc) % ancho != 0 and posy_inc%alto == 0) {
            if (tablero[fila - 1][columna - 1] == 'x') {
                return true;
            }
        }
        else if ((posx_inc) % ancho != 0 and posy_inc%alto != 0) {
            if (tablero[fila - 1][columna - 1] == 'x' or tablero[fila][columna-1] == 'x') {
                return true;
            }
        }
    }

    return false;
}

void control_maestro::colisionesfantasmas()
{
    for (int i = 0; i < 6; i++) {
        QGraphicsItem *arana_ref = arana->get_enemigo(i);
        if (mago->movimiento->collidesWithItem(arana_ref)) {
            mago->reducir_vida(5);
        }
    }
    for (int i = 0; i < 2; i++) {
        QGraphicsItem *dunde_ref = duende->get_enemigo(i);
        if  (mago->movimiento->collidesWithItem(dunde_ref)) {
             mago->reducir_vida(10);
        }
    }
    if(mago->obtener_vida() <= 0) {
        perdiste = new objetos(":/imagenes/veneno.jpg",90,120);
        // int xPos = (pantalla_juego->getUI()->graphicsView->width() - perdiste->boundingRect().width()) / 2;
        // int yPos = (pantalla_juego->getUI()->graphicsView->height() - perdiste->boundingRect().height()) / 2;
        perdiste->setPos(810, 620);
        perdiste->setZValue(+1);
        escena->addItem(perdiste);
    }

}

void control_maestro::varita() {

}

     /*perdiste=new objetos(":/imagenes/veneno.jpg",560,650);
     escena->addItem(perdiste);
     pantalla_juego->getUI()->graphicsView->setScene(escena);*/

/*void control_maestro::fin_de_juego()
{colision_enemigo=false;
 if(numero==2500){
     escena->removeItem(pacman->movimiento);
     inicio_juego=false;
     timer_enemigos->stop();
     timer_comida->stop();
     finjuego=new objetos("://imagenes/lose.jpg",560,650);
     escena->addItem(finjuego);
     pantalla_juego->getUI()->graphicsView->setScene(escena);
 }
 else if (colision_enemigo==true){
     inicio_juego=false;
     perdiste=new objetos(":/imagenes/game over.jpg",560,650);
     escena->addItem(perdiste);
     pantalla_juego->getUI()->graphicsView->setScene(escena);
 }

}*/


control_maestro::~control_maestro()
{
 delete mago;
 delete arana;
 delete pasto;
 delete baul;
 delete llave;
 delete timer;
 delete timer_caminar;
 delete timer_enemigos;
}
