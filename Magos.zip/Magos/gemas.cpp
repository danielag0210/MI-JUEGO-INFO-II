#include "gemas.h"
#include <QPainter>

gemas::gemas()
{

}

gemas::gemas(int v, int y, int l, int a, QString b)
{   this->posx=x;
    this->posy=y;
    this->vida=v;
    this->largo=l;
    this->ancho=a;
    this->url=b;
}

QRectF gemas::boundingRect() const
{
    return QRectF(posx, posy,largo,ancho);
}

void gemas::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *)
{
    QPixmap gemas1(url);
    painter->drawPixmap(boundingRect(), gemas1, gemas1.rect());
}
