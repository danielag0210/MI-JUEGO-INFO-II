#include "bala.h"

bala::bala()
{

}
