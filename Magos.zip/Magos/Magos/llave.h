#ifndef LLAVE_H
#define LLAVE_H

#include <QGraphicsItem>
#include <QString>
#include "llave.h"

class llave : public QGraphicsItem {
    int valor, posx, posy, largo, ancho;
    QString url;
public:
    llave();
    llave(int v, int x, int y, int l, int a, QString b);
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    int valor1();
};

#endif // LLAVE_H
