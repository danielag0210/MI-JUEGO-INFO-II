#ifndef PERSONAJE_H
#define PERSONAJE_H

#define n_arriba 0
#define n_abajo 1
#define n_derecha 2
#define n_izquierda 3
#define n_base 4
#define n_ancho_sprite 25
#define n_alto_sprite  40
#define caras_personaje 5

#include <QMainWindow>
#include <QGraphicsScene>
#include <QKeyEvent>
#include <QTimer>
#include <QObject>
#include <QWidget>
#include "objetos.h"
#include "mainwindow.h"
#include <QObject>
#include "control_maestro.h"


class personaje:public QObject, public QGraphicsPixmapItem
{Q_OBJECT
public:
    personaje();
    void principal_personaje();
    bool caminar1;
    char direccion;
    objetos *movimiento;//este se va a encargar de moverse entre los punteros personaje
    objetos *get_personaje_p(int numero_p);
    void personaje_arriba_c(char cara);
    void personaje_abajo_c(char cara);
    void personaje_derecha_c(char cara);
    void personaje_izquierda_c(char cara);
    int obtener_vida();
    void reducir_vida(int cantidad);
    ~personaje();
    int velocidad;
    int vida;
    char x_o_y;

    void aumentar_vida(int cantidad);

public slots:
    void caminar();
    void moverV2(char direccion);

private:
    char  paso_actua;
    int caminar_t;
    objetos *personaje_p[caras_personaje]; 
};

#endif // PERSONAJE_H
