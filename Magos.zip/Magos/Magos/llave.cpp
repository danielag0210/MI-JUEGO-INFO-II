#include "llave.h"
#include <QPainter>

llave::llave() : QGraphicsItem()
{
}

llave::llave(int v, int x, int y, int l, int a, QString b)
{   this->posx=x;
    this->posy=y;
    this->largo=l;
    this->ancho=a;
    this->url=b;
    this->valor=v;
}

QRectF llave::boundingRect() const
{
    return QRectF(posx, posy,largo,ancho);
}

int llave::valor1()
{
    return valor;
}


void llave::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *)
{
    QPixmap bloque1(url);
    painter->drawPixmap(boundingRect(), bloque1, bloque1.rect());
}
