#include "control_maestro.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "control_maestro.h"
#include "personaje.h"
#include "iostream"
#include "tablero.cpp"

#include <QString>
#include <iostream>
#include <QTimer>

using namespace std;

control_maestro::control_maestro(MainWindow* mainWindow)
{   this->pantalla_juego = mainWindow;
    this->escena = mainWindow->getEscena();
    pantalla_juego->getUI()->graphicsView->setScene(escena);

    perdiste = new bloque(810,620,90,120,":/imagenes/veneno.jpg");
    sangre = new bloque(0,0,950,780,":/imagenes/sangre-removebg-preview.png");

    ganaste = new objetos(":/imagenes/ganaste.jpg", 1000, 750);
    moriste = new objetos(":/imagenes/hasmuerto.jpg", 1000, 750);

    mago=new personaje();
    duende1 = new duende();
    arana=new enemigos();

    inicio_juego=true;
    llavetomada1=false;
    llave3 = LlaveAleatoria();

    //Mapa
    crearmapa(escena,tablero);
    pasto = new objetos(":/imagenes/pasto.png",950,750);
    pantalla_juego->setStyleSheet("background-color: black;");
    pasto->setZValue(-1);
    escena->addItem(pasto);

    arana->start='1';
    timer_enemigos = new QTimer();
    QObject::connect(timer_enemigos, SIGNAL(timeout()), arana, SLOT(mover()));
    timer_enemigos->start(60);

    duende1->start='1';
    timer_enemigos1 = new QTimer();
    QObject::connect(timer_enemigos, SIGNAL(timeout()), duende1, SLOT(mover3()));
    timer_enemigos->start(60);

    QTimer *timerColisiones = new QTimer(this);
    connect(timerColisiones, &QTimer::timeout, this, &control_maestro::colisionesfantasmas);
    timerColisiones->start(300);

    pantalla_juego->getUI()->graphicsView->setScene(escena);
    lcdnumero=pantalla_juego->getUI()->lcdNumber;

    numero=15;
    lcdnumero->display(numero);
    aggrgarMovimiento_caminar();

}

int control_maestro::LlaveAleatoria() {
         int llave2 = rand() % 2;
         return llave2;
}


void control_maestro::aggrgarMovimiento_caminar()
{  timer_caminar=new QTimer();
    QObject::connect(timer_caminar, SIGNAL(timeout()), mago, SLOT(caminar()));
    timer_caminar->start(100);
}


void control_maestro::focus(QGraphicsItem *item){
    QRectF pos = escena->sceneRect();
    escena->setSceneRect(
        pos.x(),
        pos.y(),
        escena->width(),
        escena->height()
    );
}


void control_maestro::keyPressEvent(QKeyEvent* event)
{
    focus(mago->movimiento);
      if (event->key() == Qt::Key_W) { // Arriba
            direccion='w';
            varita();
            gemita();
            fin_de_juego();
            if(colision(mago->movimiento->x(),mago->movimiento->y()-mago->velocidad,direccion)==false){//aqui hacemos que haga el paso para verificar si se puede hacer
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_arriba)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_arriba)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_arriba);
                mago->moverV2(direccion);
                mago->x_o_y='w';
                escena->addItem(mago->movimiento);
            }
            else{
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_base)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_base)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_base);
                escena->addItem(mago->movimiento);
            }
        }

        else if (event->key() == Qt::Key_S) { // abajo
            direccion='s';
            varita();
            gemita();
            fin_de_juego();
            if(colision(mago->movimiento->x(),mago->movimiento->y()+mago->velocidad,direccion)==false){
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_abajo)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_abajo)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_abajo);
                mago->moverV2(direccion);
                mago->x_o_y='s';
                escena->addItem(mago->movimiento);
            }
            else{
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_base)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_base)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_base);
                escena->addItem(mago->movimiento);
            }

        }
        else if (event->key() == Qt::Key_D) { // derecha
            direccion='d';
            varita();
            gemita();
            fin_de_juego();
            if(colision(mago->movimiento->x()+mago->velocidad,mago->movimiento->y(),direccion)==false){
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_derecha)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_derecha)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_derecha);
                mago->moverV2(direccion);
                mago->x_o_y='d';
                escena->addItem(mago->movimiento);
            }
            else{
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_base)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_base)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_base);
                escena->addItem(mago->movimiento);
            }

        }
        else if (event->key() == Qt::Key_A) { // izquierda
            direccion='a';
            varita();
            gemita();
            fin_de_juego();
            if(colision(mago->movimiento->x()-mago->velocidad,mago->movimiento->y(),direccion)==false){
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_izquierda)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_izquierda)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_izquierda);
                mago->moverV2(direccion);
                mago->x_o_y='a';
                escena->addItem(mago->movimiento);
            }
            else{
                escena->removeItem(mago->movimiento);
                mago->get_personaje_p(n_base)->setY(mago->movimiento->y());//le damos la pocicion en x y y del personaje
                mago->get_personaje_p(n_base)->setX(mago->movimiento->x());
                mago->movimiento=mago->get_personaje_p(n_base);
                escena->addItem(mago->movimiento);
            }
      }
}



void control_maestro::crearmapa(QGraphicsScene *escena, char tablero[31][40]){
    // Calcular el ancho y alto de cada  cuadro en la matriz
    int  anchoc = 25;
    int  altoc =  25;
    int  aranas = 0;
    int  duendes =0;
    //macros
    pantalla_juego->tamano_de_la_escena(0,0,1100,780);//aqui le damos el tamaño a la escena
    pantalla_juego->setGeometry(0,0,1100,780);//aqui le damos tamaño al la pantalla

    for (int y = 0; y < 32; y++) {
        for (int x = 0; x < 40; x++) {
            if (tablero[y][x] == 'x') {
                // Calcular la posición del objeto muro
                int posX = x * anchoc;
                int posY = y * altoc;
                // Crear el objeto muro y agregarlo al grupo
                muro = new bloque(posX, posY, anchoc, altoc, ":/imagenes/bloque.jpg");
                escena->addItem(muro);
            }
             else if (tablero_lugares[y][x] == 'm') {
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    mago->movimiento->setPos(posX,posY);
            }
            else if(tablero_lugares[y][x]=='a'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    arana->get_enemigo(aranas)->setPos(posX,posY);
                    escena->addItem(arana->get_enemigo(aranas));
                    aranas=aranas+1;
            }
            else if(tablero_lugares[y][x]=='d'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    duende1->obtenerDuende(duendes)->setPos(posX,posY);
                    escena->addItem(duende1->obtenerDuende(duendes));
                    duendes=duendes+1;
            }
            else if(tablero_lugares[y][x]=='b'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    baul = new bloque(posX,posY,40,35,":/imagenes/baul.png");
                    escena->addItem(baul);
            }

            else if(tablero_lugares[y][x]=='y'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    llabe = new llave(0,posX,posY,20,30,":/imagenes/llave-removebg-preview.png");
                    llaves.append(llabe);
                    escena->addItem(llabe);
            }
            else if(tablero_lugares[y][x]=='l'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    llabe = new llave(1,posX,posY,20,30,":/imagenes/llave-removebg-preview.png");
                    llaves.append(llabe);
                    escena->addItem(llabe);
            }
            else if(tablero_lugares[y][x]=='g'){
                    int posX = x * anchoc;
                    int posY = y * altoc;
                    gema = new bloque(posX,posY,20,20,":/imagenes/diamantes-removebg-preview (2).png");
                    gemas.append(gema);
                    escena->addItem(gema);
            }
        }
    }
}

    bool control_maestro::colision(int posx_inc, int posy_inc, char direccion)
{
    int ancho = 25;
    int alto =  25;
    int objeto_x = posx_inc / ancho;
    int objeto_y = posy_inc / alto;
    int fila = objeto_y + 1;
    int columna = objeto_x + 1;

    if (direccion == 'w') {
        // hay que colocar las siguientes condiciones:
        // si pos_inc y % alto == 0 true
        // si la x - velm % == 0
        // si la x % != 0 pero y % == 0
        // si la x % != 0 y y % != 0
        if (posy_inc % alto == 0) {
            return false;
        }
        else if ((posy_inc - mago->velocidad) % ancho == 0 and tablero[fila - 1][columna - 1] == 'x') {
            return true;
        }
        else if ((posy_inc) % ancho != 0 and posx_inc % alto == 0) {
            if (tablero[fila - 1][columna - 1] == 'x') {
                return true;
            }
        }
        else if ((posy_inc) % ancho != 0 and posx_inc % alto != 0) {
            if (tablero[fila - 1][columna - 1] == 'x' or tablero[fila-1][columna] == 'x') {
                return true;
            }
        }
    }
    else if (direccion == 's') {
        if (posy_inc % alto == 0) {
            return false;
        }
        else if ((posy_inc - mago->velocidad) % ancho == 0 and tablero[fila][columna-1] == 'x') {
            return true;
        }
        else if ((posy_inc) % ancho != 0 and posx_inc % alto == 0) {
            if (tablero[fila][columna-1] == 'x') {
                return true;
            }
        }
        else if ((posy_inc) % ancho != 0 and posx_inc % alto != 0) {
            if (tablero[fila][columna - 1] == 'x' or tablero[fila][columna] == 'x') {
                return true;
            }
        }
    }
    else if (direccion == 'd') {
        if (posx_inc % ancho == 0) {
            return false;
        }
        else if ((posx_inc - mago->velocidad) % ancho == 0 and tablero[fila-1][columna] == 'x') {
            return true;
        }
        else if ((posx_inc) % ancho != 0 and posy_inc%alto == 0) {
            if (tablero[fila - 1][columna] == 'x') {
                return true;
            }
        }
        else if ((posx_inc) % ancho != 0 and posy_inc%alto != 0) {
            if (tablero[fila][columna] == 'x' or tablero[fila-1][columna] == 'x') {
                return true;
            }
        }
    }
    else if (direccion == 'a') {
        if (posx_inc % ancho == 0) {
            return false;
        }
        else if ((posx_inc - mago->velocidad) % ancho == 0 and tablero[fila - 1][columna - 1] == 'x') {
            return true;
        }
        else if ((posx_inc) % ancho != 0 and posy_inc%alto == 0) {
            if (tablero[fila - 1][columna - 1] == 'x') {
                return true;
            }
        }
        else if ((posx_inc) % ancho != 0 and posy_inc%alto != 0) {
            if (tablero[fila - 1][columna - 1] == 'x' or tablero[fila][columna-1] == 'x') {
                return true;
            }
        }
    }

    return false;
}




void control_maestro::fin_de_juego()
{
    if (llavetomada1 == true && baul->collidesWithItem(mago->movimiento))
    {
        escena->addItem(ganaste);
        inicio_juego=false;
    }
}

void control_maestro::gemita() {
    QList<bloque*>::iterator it = gemas.begin();
    while (it != gemas.end()) {
        if ((*it)->collidesWithItem(mago->movimiento))  {
            escena->removeItem(*it);
            delete *it;
            it = gemas.erase(it);
            mago->aumentar_vida(5);
            numero=numero+5;
            lcdnumero->display(numero);
        }
        else {
            ++it;
        }
    }
}

void control_maestro::varita() {
    QList<llave*>::iterator it = llaves.begin();
    while (it != llaves.end()) {
        int x = (*it)->valor1();
        if ((*it)->collidesWithItem(mago->movimiento) && x == llave3) {
            escena->removeItem(*it);
            delete *it;
            it = llaves.erase(it);
            llavetomada1=true;

            fin_de_juego();
        }
        else {
            ++it;
        }
    }
}

void control_maestro::colisionesfantasmas()
{
    for (int i = 0; i < 6; i++) {
        QGraphicsItem *arana1 = arana->get_enemigo(i);
        if (mago->movimiento->collidesWithItem(arana1)) {
            numero -= 5;
            lcdnumero->display(numero);
            mostrarPerdiste();

            if (numero == 0) {
            inicio_juego=true;
            escena->addItem(moriste);
            reiniciar();

        }
    }
}
    for (int i = 0; i < 2; i++) {
    QGraphicsItem *duende2 = duende1->obtenerDuende(i);
        if (mago->movimiento->collidesWithItem(duende2)) {
                numero -= 10;
                lcdnumero->display(numero);
                mostrarsangre();
                if (numero <= 0) {
                inicio_juego=false;
                escena->addItem(moriste);
                reiniciar();

                }
        }
    }
}

void control_maestro::mostrarsangre()
{

sangre->setZValue(+1);
escena->addItem(sangre);
QTimer::singleShot(800, this, &control_maestro::ocultarsangre);

}

void control_maestro::ocultarsangre()
{   escena->removeItem(sangre);
}


void control_maestro::mostrarPerdiste()
{
    perdiste->setZValue(+1);
    escena->addItem(perdiste);
    QTimer::singleShot(800, this, &control_maestro::ocultarPerdiste);

}

void control_maestro::ocultarPerdiste()
{   escena->removeItem(perdiste);
}

void control_maestro::reiniciar() {
    escena->removeItem(mago);
    QTimer::singleShot(5000, this, &control_maestro::cerrarVentana);
}

void control_maestro::cerrarVentana() {
    mainWindow->close();

}

void control_maestro::pantall2()
{
    holi = new pantalla2();
    holi->mostrar();
}


control_maestro::~control_maestro()
{

 delete mago;
 delete duende1;
 delete arana;
 delete pasto;
 delete baul;
 delete timer;
 delete timer_caminar;
 delete timer_enemigos;
 delete timer_enemigos1;

}
