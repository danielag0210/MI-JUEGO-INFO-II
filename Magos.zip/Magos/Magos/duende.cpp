#include "duende.h"

char tablero_duende[32][40] = {
        {"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"},
        {"x                                     x"},
        {"x                                     x"},
        {"x  xxxxxxx  xxxxxxxxxxxxxxx  xxxxxxx  x"},
        {"x  x                               x  x"},
        {"x  x                               x  x"},
        {"x  x  xxxx  x   xxxxxxx   x  xxxx  x  x"},
        {"x  x  x xx  x   xx   xx   x  xx x  x  x"},
        {"x  x  x  x  x   xx   xx   x  x  x  x  x"},
        {"x  x  x  x  x             x  x  x  x  x"},
        {"x  x  x  x  x             x  x  x  x  x"},
        {"xxxx  x  x  xxxxxx   xxxxxx  x  x  xxxx"},
        {"x     x  x       x   x       x  x     x"},
        {"x     x  x       x   x       x  x     x"},
        {"xxxxxxx  xxxxxxxxx   xxxxxxxxx  xxxxxxx"},
        {"x                                     x"},
        {"x                                     x"},
        {"x     x  x                   x  x     x"},
        {"xxxxxxx  x  xxxxxx   xxxxxx  x  xxxxxxx"},
        {"x        x  xxxxxx   xxxxxx  x        x"},
        {"x       xx  xxxxxx   xxxxxx  xx       x"},
        {"xxxxxxxxxx                   xxxxxxxxxx"},
        {"x                                     x"},
        {"x                                     x"},
        {"xxxxxxxxxx  xxxxxxxxxxxxxxx  xxxxxxxxxx"},
        {"xxxxxxxxxx  x             x  xxxxxxxxxx"},
        {"xxxxxxxxxx  x             x  xxxxxxxxxx"},
        {"xxxxxxxxxx                   xxxxxxxxxx"},
        {"xxxxxxxxxx                   xxxxxxxxxx"},
        {"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"}
};

duende::duende()
{
    srand(time(NULL));
    duende_g[0] = new objetos(":/imagenes/duende_frente1.png", 30, 40);
    duende_g[1] = new objetos(":/imagenes/duende_frente1.png", 30, 40);
    inicializarDireccionesAleatorias();
    velocidad = 6;
}

objetos* duende::obtenerDuende(int duende1)
{
    return duende_g[duende1];
}

char duende::obtenerPosicionAleatoria()
{
    char direcciones[] = {'w', 's'};
    int valor = rand() % 2;
    return direcciones[valor];
}



bool duende::colision(int posx_inc, int posy_inc, char direccion)
{
    int ancho = 25;//sprites
    int alto = 25;
    int objeto_x = posx_inc / ancho;
    int objeto_y = posy_inc / alto;
    int fila = objeto_y + 1;  // Sumar 1 para compensar el índice base 0 en C++
    int columna = objeto_x + 1;  // Sumar 1 para compensar el índice base 0 en C++

    if (direccion == 'w') {
        if (posy_inc % alto == 0) {
            return false;
        } else if ((posy_inc - velocidad) % ancho == 0 and tablero_duende[fila - 1][columna - 1] == 'x') {
            return true;
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto == 0) {
            if (tablero_duende[fila - 1][columna - 1] == 'x') {
                return true;
            }
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto != 0) {
            if (tablero_duende[fila - 1][columna - 1] == 'x' or tablero_duende[fila-1][columna] == 'x') {
                return true;
            }
        }
    } else if (direccion == 's') {
        if (posy_inc % alto == 0) {
            return false;
        } else if ((posy_inc - velocidad) % ancho == 0 and tablero_duende[fila][columna-1] == 'x') {
            return true;
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto == 0) {
            if (tablero_duende[fila][columna-1] == 'x') {
                return true;
            }
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto != 0) {
            if (tablero_duende[fila][columna - 1] == 'x' or tablero_duende[fila][columna] == 'x') {
                return true;
            }
        }
    } else if (direccion == 'd') {
        if (posx_inc % ancho == 0) {
            return false;
        } else if ((posx_inc - velocidad) % ancho == 0 and tablero_duende[fila-1][columna] == 'x') {
            return true;
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto == 0) {
            if (tablero_duende[fila - 1][columna] == 'x') {
                return true;
            }
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto != 0) {
            if (tablero_duende[fila][columna] == 'x' or tablero_duende[fila-1][columna] == 'x') {
                return true;
            }
        }
    } else if (direccion == 'a') {
        if (posx_inc % ancho == 0) {
            return false;
        } else if ((posx_inc - velocidad) % ancho == 0 and tablero_duende[fila - 1][columna - 1] == 'x') {
            return true;
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto == 0) {
            if (tablero_duende[fila - 1][columna - 1] == 'x') {
                return true;
            }
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto != 0) {
            if (tablero_duende[fila - 1][columna - 1] == 'x' or tablero_duende[fila][columna-1] == 'x') {
                return true;
            }
        }
    }
    return false;
}

void duende::mover3()
{
    for (int i = 0; i < 2; i++) {
        int x = duende_g[i]->x();
        int y = duende_g[i]->y();

        if (direccion[i] == 'w') {
            if (colision(x, y - velocidad, direccion[i])) {

                char nuevaDireccion = obtenerPosicionAleatoria();
                while (nuevaDireccion == direccion[i]) {
                    nuevaDireccion = obtenerPosicionAleatoria();
                }
                direccion[i] = nuevaDireccion;
            } else {
                duende_g[i]->setY(y - velocidad);
            }
        } else if (direccion[i] == 's') {
            if (colision(x, y + velocidad, direccion[i])) {

                char nuevaDireccion = obtenerPosicionAleatoria();
                while (nuevaDireccion == direccion[i]) {
                    nuevaDireccion = obtenerPosicionAleatoria();
                }
                direccion[i] = nuevaDireccion;
            } else {
                duende_g[i]->setY(y + velocidad);
            }
        }
    }
}

void duende::inicializarDireccionesAleatorias() {
    direccion[0] = obtenerPosicionAleatoria();
    direccion[1] = obtenerPosicionAleatoria();
}




