#include "enemigos.h"

char tablero_aranas[32][40] = {
    {"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"},
    {"x                                     x"},
    {"x                                     x"},
    {"x  xxxxxxx  xxxxxxxxxxxxxxx  xxxxxxx  x"},
    {"x  x                               x  x"},
    {"x  x                               x  x"},
    {"x  x  xxxx  x   xxxxxxx   x  xxxx  x  x"},
    {"x  x  x  x  x   xx   xx   x  x  x  x  x"},
    {"x  x  x  x  x   xx   xx   x  x  x  x  x"},
    {"x  x  x  x  x             x  x  x  x  x"},
    {"x  x  x  x  x             x  x  x  x  x"},
    {"xxxx  x  x  xxxxxx   xxxxxx  x  x  xxxx"},
    {"x     x  x       x   x       x  x     x"},
    {"x     x  x       x   x       x  x     x"},
    {"xxxxxxx  xxxxxxxxx   xxxxxxxxx  xxxxxxx"},
    {"x                                     x"},
    {"x                                     x"},
    {"x     x  x                   x  x     x"},
    {"xxxxxxx  x  xxxxxx   xxxxxx  x  xxxxxxx"},
    {"x        x  xxxxxx   xxxxxx  x        x"},
    {"x        x  xxxxxx   xxxxxx  x        x"},
    {"xxxxxxxxxx                   xxxxxxxxxx"},
    {"x                                     x"},
    {"x                                     x"},
    {"xxxxxxxxxx  xxxxxxxxxxxxxxx  xxxxxxxxxx"},
    {"xxxxxxxxxx  x             x  xxxxxxxxxx"},
    {"xxxxxxxxxx  x             x  xxxxxxxxxx"},
    {"xxxxxxxxxx                   xxxxxxxxxx"},
    {"xxxxxxxxxx                   xxxxxxxxxx"},
    {"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"}
};

enemigos::enemigos()
{   srand(time(NULL));
    enemigos_g[0]=new objetos(":/imagenes/arana.png",25,25);
    enemigos_g[1]=new objetos(":/imagenes/arana.png",25,25);
    enemigos_g[2]=new objetos(":/imagenes/arana.png",25,25);
    enemigos_g[3]=new objetos(":/imagenes/arana.png",25,25);
    enemigos_g[4]=new objetos(":/imagenes/arana.png",25,25);
    enemigos_g[5]=new objetos(":/imagenes/arana.png",25,25);
    enemigos_g[6]=new objetos(":/imagenes/arana.png",25,25);
    inicializarDireccionesAleatorias();
}

char enemigos::obtenerPosicionAleatoria() {
    char valor;
    valor = rand() % 4;
    char direcciones[] = {'w', 's', 'd', 'a'};
    return direcciones[valor];
}

objetos *enemigos::get_enemigo(int enemigo)
{
    return enemigos_g[enemigo];
}


bool enemigos::colision(int posx_inc, int posy_inc, char direccion)
{
    int ancho = 25;
    int alto = 25;
    int objeto_x = posx_inc / ancho;
    int objeto_y = posy_inc / alto;
    int fila = objeto_y + 1;
    int columna = objeto_x + 1;

    if (direccion == 'w') {
        if (posy_inc % alto == 0) {
            return false;
        } else if ((posy_inc - velocidad) % ancho == 0 and tablero_aranas[fila - 1][columna - 1] == 'x') {
            return true;
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto == 0) {
            if (tablero_aranas[fila - 1][columna - 1] == 'x') {
                return true;
            }
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto != 0) {
            if (tablero_aranas[fila - 1][columna - 1] == 'x' or tablero_aranas[fila-1][columna] == 'x') {
                return true;
            }
        }
    } else if (direccion == 's') {
        if (posy_inc % alto == 0) {
            return false;
        } else if ((posy_inc - velocidad) % ancho == 0 and tablero_aranas[fila][columna-1] == 'x') {
            return true;
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto == 0) {
            if (tablero_aranas[fila][columna-1] == 'x') {
                return true;
            }
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto != 0) {
            if (tablero_aranas[fila][columna - 1] == 'x' or tablero_aranas[fila][columna] == 'x') {
                return true;
            }
        }
    } else if (direccion == 'd') {
        if (posx_inc % ancho == 0) {
            return false;
        } else if ((posx_inc - velocidad) % ancho == 0 and tablero_aranas[fila-1][columna] == 'x') {
            return true;
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto == 0) {
            if (tablero_aranas[fila - 1][columna] == 'x') {
                return true;
            }
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto != 0) {
            if (tablero_aranas[fila][columna] == 'x' or tablero_aranas[fila-1][columna] == 'x') {
                return true;
            }
        }
    } else if (direccion == 'a') {
        if (posx_inc % ancho == 0) {
            return false;
        } else if ((posx_inc - velocidad) % ancho == 0 and tablero_aranas[fila - 1][columna - 1] == 'x') {
            return true;
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto == 0) {
            if (tablero_aranas[fila - 1][columna - 1] == 'x') {
                return true;
            }
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto != 0) {
            if (tablero_aranas[fila - 1][columna - 1] == 'x' or tablero_aranas[fila][columna-1] == 'x') {
                return true;
            }
        }
    }

    return false;

}

void enemigos::mover()
{
    for (int i = 0; i < 6; i++) {
        // Obtener posición actual del enemigo
        int x = enemigos_g[i]->x();
        int y = enemigos_g[i]->y();

        // Verificar si hay colisión en la dirección actual
        if (direccion[i]=='w'){
            if (colision(x, y-velocidad, direccion[i])) {
                // Cambiar a una nueva dirección aleatoria diferente a la actual
                char nuevaDireccion = obtenerPosicionAleatoria();
                while (nuevaDireccion == direccion[i]) {
                    nuevaDireccion = obtenerPosicionAleatoria();
                }
                direccion[i] = nuevaDireccion;
            }
            else{enemigos_g[i]->setY(y - velocidad);}

        }
        else if(direccion[i]=='s'){
            if (colision(x, y+velocidad, direccion[i])) {
                // Cambiar a una nueva dirección aleatoria diferente a la actual
                char nuevaDireccion = obtenerPosicionAleatoria();
                while (nuevaDireccion == direccion[i]) {
                    nuevaDireccion = obtenerPosicionAleatoria();
                }
                direccion[i] = nuevaDireccion;
            }
            else{enemigos_g[i]->setY(y + velocidad);}

        }
        else if(direccion[i]=='a'){
            if (colision(x-velocidad, y, direccion[i])) {
                // Cambiar a una nueva dirección aleatoria diferente a la actual
                char nuevaDireccion = obtenerPosicionAleatoria();
                while (nuevaDireccion == direccion[i]) {
                    nuevaDireccion = obtenerPosicionAleatoria();
                }
                direccion[i] = nuevaDireccion;
            }
            else{enemigos_g[i]->setX(x - velocidad);}

        }
        else if(direccion[i]=='d'){
            if (colision(x+velocidad, y, direccion[i])) {
                // Cambiar a una nueva dirección aleatoria diferente a la actual
                char nuevaDireccion = obtenerPosicionAleatoria();
                while (nuevaDireccion == direccion[i]) {
                    nuevaDireccion = obtenerPosicionAleatoria();
                }
                direccion[i] = nuevaDireccion;
            }
            else{enemigos_g[i]->setX(x + velocidad);}

        }

    }
}
void enemigos::inicializarDireccionesAleatorias() {
    direccion[0] = obtenerPosicionAleatoria();
    direccion[1] = obtenerPosicionAleatoria();
    direccion[2] = obtenerPosicionAleatoria();
    direccion[3] = obtenerPosicionAleatoria();
    direccion[4] = obtenerPosicionAleatoria();
    direccion[5] = obtenerPosicionAleatoria();
    direccion[6] = obtenerPosicionAleatoria();
}

