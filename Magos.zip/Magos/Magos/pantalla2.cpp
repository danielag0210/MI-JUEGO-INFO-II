#include "pantalla2.h"
#include "ui_pantalla2.h"
#include "mainwindow.h"

pantalla2::pantalla2(QWidget *parent) : QMainWindow(parent), ui(new Ui::pantalla2)
{
    ui->setupUi(this);
    inicio = new QGraphicsScene;
    ui->graphicsView->setScene(inicio);
    setWindowTitle("Magical Wand");
    setWindowIcon(QPixmap(":/imagenes/duende_frente1.png"));

    primero = new objetos(":/imagenes/inicio.jpg",950,750);
    primero->setZValue(-1);
    inicio->addItem(primero);

    int x_inicial = 0,
        y_inicial = 0;
    int ancho = ui->graphicsView->width(),
         alto = ui->graphicsView->height();

    inicio->setSceneRect(x_inicial,y_inicial,ancho-2,alto-2);
}

pantalla2::~pantalla2()
{
    delete ui;
}

void pantalla2::mostrar() {
    show();
}

void pantalla2::on_pushButton_pressed()
{
    pn = new MainWindow(this);
    pn->show();
    hide();
}
