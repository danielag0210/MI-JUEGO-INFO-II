#ifndef DUENDE_H
#define DUENDE_H
#include <QObject>
#include <QGraphicsPixmapItem>
#include <QTimer>
#include <random>
#include <ctime>

#include "objetos.h"

class duende : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT // Agregamos la macro Q_OBJECT
public:
    duende();
    objetos* obtenerDuende(int duende1);
    char obtenerPosicionAleatoria();
    void inicializarDireccionesAleatorias();
    char start;

public slots:
    void mover3();

private:
    bool colision(int posx_inc, int posy_inc, char direccion);
    int velocidad;
    objetos* duende_g[2];
    char direccion[2];
};


#endif // DUENDE_H
