#include "pantalla2.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    pantalla2 p2;
    p2.show();
    return a.exec();
}
