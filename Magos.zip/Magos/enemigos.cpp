#include "enemigos.h"

char tablero_fantasma[32][40] = {
    {"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"},
    {"x                                     x"},
    {"x                                     x"},
    {"x  xxxxxxx  xxxxxxxxxxxxxxx  xxxxxxx  x"},
    {"x  x                               x  x"},
    {"x  x                               x  x"},
    {"x  x  xxxx  x   xxxxxxx   x  xxxx  x  x"},
    {"x  x  x  x  x   xx   xx   x  x  x  x  x"},
    {"x  x  x  x  x   xx   xx   x  x  x  x  x"},
    {"x  x  x  x  x             x  x  x  x  x"},
    {"x  x  x  x  x             x  x  x  x  x"},
    {"xxxx  x  x  xxxxxx   xxxxxx  x  x  xxxx"},
    {"x     x  x       x   x       x  x     x"},
    {"x     x  x       x   x       x  x     x"},
    {"xxxxxxx  xxxxxxxxx   xxxxxxxxx  xxxxxxx"},
    {"x                                     x"},
    {"x                                     x"},
    {"x     x  x                   x  x     x"},
    {"xxxxxxx  x  xxxxxx   xxxxxx  x  xxxxxxx"},
    {"x        x  xxxxxx   xxxxxx  x        x"},
    {"x        x  xxxxxx   xxxxxx  x        x"},
    {"xxxxxxxxxx                   xxxxxxxxxx"},
    {"x                                     x"},
    {"x                                     x"},
    {"xxxxxxxxxx  xxxxxxxxxxxxxxx  xxxxxxxxxx"},
    {"xxxxxxxxxx  x             x  xxxxxxxxxx"},
    {"xxxxxxxxxx  x             x  xxxxxxxxxx"},
    {"xxxxxxxxxx                   xxxxxxxxxx"},
    {"xxxxxxxxxx                   xxxxxxxxxx"},
    {"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"}
};

enemigos::enemigos(int tipo)
{
    srand(time(NULL));//inicializamos la semilla random

    // XAN: Tipos de niveles de dificultad
    // 1: 2 arañas velocidad 3 y 1 duende velocidad 6
    // 2: 4 arañas velocidad 4 y 2 duende velocidad 7
    // 1: 6 arañas velocidad 5 y 3 duende velocidad 8

    if(tipo == 0) {
        enemigos_a.append(new objetos(":/imagenes/arana.png",25,25));
        enemigos_a.append(new objetos(":/imagenes/arana.png",25,25));
        enemigos_a.append(new objetos(":/imagenes/arana.png",25,25));
        enemigos_a.append(new objetos(":/imagenes/arana.png",25,25));
        enemigos_a.append(new objetos(":/imagenes/arana.png",25,25));
        enemigos_a.append(new objetos(":/imagenes/arana.png",25,25));

        /*enemigos_a[0]=new objetos(":/imagenes/arana.png",25,25);
        enemigos_a[1]=new objetos(":/imagenes/arana.png",25,25);
        enemigos_a[2]=new objetos(":/imagenes/arana.png",25,25);
        enemigos_a[3]=new objetos(":/imagenes/arana.png",25,25);
        // XAN: Validar el por qué no se muestran las últimas dos arañas
        enemigos_a[4]=new objetos(":/imagenes/arana.png",25,25);
        enemigos_a[5]=new objetos(":/imagenes/arana.png",25,25);*/
    }
    else {

        enemigos_a.append(new objetos(":/imagenes/duende_frente1.png",25,25));
        enemigos_a.append(new objetos(":/imagenes/duende_frente1.png",25,25));
        /*enemigos_a[0]=new objetos(":/imagenes/duende_frente1.png",25,25);
        enemigos_a[1]=new objetos(":/imagenes/duende_frente1.png",25,25);*/
    }

    inicializarDireccionesAleatorias();//le damos direccion inicial a los fantasmas
}

char enemigos::obtenerPosicionAleatoria() {
    char valor;
    valor = rand() % 4;
    char direcciones[] = {'w', 's', 'd', 'a'};
    return direcciones[valor];
}

objetos *enemigos::get_enemigo(int enemigo)
{
    return enemigos_a[enemigo];
}

void enemigos::eliminar_enemigo(int enemigo)
{
    // XAN: transformar este arreglo en una lista y eliminar la referencia a memoria del espacio del enemigo eliminado
    // Referencia de la solución en enemigos.h
    enemigos_a[enemigo] = NULL;
}


bool enemigos::colision(int posx_inc, int posy_inc, char direccion)
{
    int ancho = 25;//sprites
    int alto = 25;
    int objeto_x = posx_inc / ancho;
    int objeto_y = posy_inc / alto;
    int fila = objeto_y + 1;  // Sumar 1 para compensar el índice base 0 en C++
    int columna = objeto_x + 1;  // Sumar 1 para compensar el índice base 0 en C++

    if (direccion == 'w') {
        if (posy_inc % alto == 0) {
            return false;
        } else if ((posy_inc - velocidad) % ancho == 0 and tablero_fantasma[fila - 1][columna - 1] == 'x') {
            return true;
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto == 0) {
            if (tablero_fantasma[fila - 1][columna - 1] == 'x') {
                return true;
            }
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto != 0) {
            if (tablero_fantasma[fila - 1][columna - 1] == 'x' or tablero_fantasma[fila-1][columna] == 'x') {
                return true;
            }
        }
    } else if (direccion == 's') {
        if (posy_inc % alto == 0) {
            return false;
        } else if ((posy_inc - velocidad) % ancho == 0 and tablero_fantasma[fila][columna-1] == 'x') {
            return true;
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto == 0) {
            if (tablero_fantasma[fila][columna-1] == 'x') {
                return true;
            }
        } else if ((posy_inc) % ancho != 0 and posx_inc % alto != 0) {
            if (tablero_fantasma[fila][columna - 1] == 'x' or tablero_fantasma[fila][columna] == 'x') {
                return true;
            }
        }
    } else if (direccion == 'd') {
        if (posx_inc % ancho == 0) {
            return false;
        } else if ((posx_inc - velocidad) % ancho == 0 and tablero_fantasma[fila-1][columna] == 'x') {
            return true;
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto == 0) {
            if (tablero_fantasma[fila - 1][columna] == 'x') {
                return true;
            }
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto != 0) {
            if (tablero_fantasma[fila][columna] == 'x' or tablero_fantasma[fila-1][columna] == 'x') {
                return true;
            }
        }
    } else if (direccion == 'a') {
        if (posx_inc % ancho == 0) {
            return false;
        } else if ((posx_inc - velocidad) % ancho == 0 and tablero_fantasma[fila - 1][columna - 1] == 'x') {
            return true;
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto == 0) {
            if (tablero_fantasma[fila - 1][columna - 1] == 'x') {
                return true;
            }
        } else if ((posx_inc) % ancho != 0 and posy_inc%alto != 0) {
            if (tablero_fantasma[fila - 1][columna - 1] == 'x' or tablero_fantasma[fila][columna-1] == 'x') {
                return true;
            }
        }
    }

    return false;

}

void enemigos::mover()
{
    // XAN: Esto puede ser la razón por la que los enemigos adicionals no se muestran
    // Si utilizan std::vector/list/map ->size, en los tres hay una función que es el size
    for (int i = 0; i < enemigos_a.length(); i++) {
        // Obtener posición actual del enemigo
        int x = enemigos_a[i]->x();
        int y = enemigos_a[i]->y();

        // Verificar si hay colisión en la dirección actual
        if (direccion[i]=='w'){
            if (colision(x, y-velocidad, direccion[i])) {
                // Cambiar a una nueva dirección aleatoria diferente a la actual
                char nuevaDireccion = obtenerPosicionAleatoria();
                while (nuevaDireccion == direccion[i]) {
                    nuevaDireccion = obtenerPosicionAleatoria();
                }
                direccion[i] = nuevaDireccion;
            }
            else{enemigos_a[i]->setY(y - velocidad);}

        }
        else if(direccion[i]=='s'){
            if (colision(x, y+velocidad, direccion[i])) {
                // Cambiar a una nueva dirección aleatoria diferente a la actual
                char nuevaDireccion = obtenerPosicionAleatoria();
                while (nuevaDireccion == direccion[i]) {
                    nuevaDireccion = obtenerPosicionAleatoria();
                }
                direccion[i] = nuevaDireccion;
            }
            else{enemigos_a[i]->setY(y + velocidad);}

        }
        else if(direccion[i]=='a'){
            if (colision(x-velocidad, y, direccion[i])) {
                // Cambiar a una nueva dirección aleatoria diferente a la actual
                char nuevaDireccion = obtenerPosicionAleatoria();
                while (nuevaDireccion == direccion[i]) {
                    nuevaDireccion = obtenerPosicionAleatoria();
                }
                direccion[i] = nuevaDireccion;
            }
            else{enemigos_a[i]->setX(x - velocidad);}

        }
        else if(direccion[i]=='d'){
            if (colision(x+velocidad, y, direccion[i])) {
                // Cambiar a una nueva dirección aleatoria diferente a la actual
                char nuevaDireccion = obtenerPosicionAleatoria();
                while (nuevaDireccion == direccion[i]) {
                    nuevaDireccion = obtenerPosicionAleatoria();
                }
                direccion[i] = nuevaDireccion;
            }
            else{enemigos_a[i]->setX(x + velocidad);}

        }

    }
}
void enemigos::inicializarDireccionesAleatorias() {
    // XAN: aquí también afecta el número de enemigos que estás renderizando
    // for(int i = 0; i < lista_enemigos.size(); i++)
    for(int i = 0; i < enemigos_a.length(); i++){
        direccion.append(obtenerPosicionAleatoria());
        /*direccion[0] = obtenerPosicionAleatoria();
        direccion[1] = obtenerPosicionAleatoria();
        direccion[2] = obtenerPosicionAleatoria();
        direccion[3] = obtenerPosicionAleatoria();*/
    }
}



