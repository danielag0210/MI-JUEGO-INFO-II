#ifndef BLOQUE_H
#define BLOQUE_H

#include <QGraphicsItem>
#include <QString>
#include "bloque.h"

class bloque : public QGraphicsItem {
    int posx, posy, largo, ancho;
    QString url;
public:
    bloque();
    bloque(int x, int y, int l, int a, QString b);
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};

#endif // BLOQUE_H
